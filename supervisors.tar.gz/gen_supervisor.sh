#!/bin/bash

projectName=$1

function build() {
  [ -d $projectName/log ] || mkdir -p $projectName/log
  cp supervisor_factory/supervise.source $projectName/supervise_$projectName  
  cp supervisor_factory/load.sh.source $projectName/load_$projectName.sh
}

if [ $# -eq 0 ];
  then
    echo "*******Usage: gen_supervisor.sh {projectName} ********"
  else
    echo "******* Generate Supervisor Service For $projectName ********"
    build
    echo "succes"
fi

